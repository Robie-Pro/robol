import updater
from .interpreter import run_file
from .updater import update_robol
import sys, os

if cmd == "update":
    updater.update()
    
def main():
    if len(sys.argv) < 2:
        print("Usage: robol <file.rmsl>  or  robol --update")
        return
    arg = sys.argv[1]
    if arg == "--update":
        update_robol()
        return
    if not arg.endswith(".rmsl"):
        print("Error: robol only runs .rmsl files")
        return
    if not os.path.exists(arg):
        print("File not found:", arg)
        return
    run_file(arg)

if __name__ == "__main__":
    main()
