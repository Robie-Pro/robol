import urllib.request
import zipfile
import os
import sys

UPDATE_URL = "https://github.com/Robie-Pro/robol/raw/main/robol.zip"

def update():
    print("Downloading latest robol.zip...")
    urllib.request.urlretrieve(UPDATE_URL, "robol_update.zip")

    print("Extracting...")
    with zipfile.ZipFile("robol_update.zip", "r") as z:
        z.extractall(os.path.dirname(__file__))

    os.remove("robol_update.zip")
    print("Update complete!")

if __name__ == "__main__":
    update()
