
import urllib.request
import os
import subprocess
import sys
import tempfile

UPDATE_URL = "https://example.com/robol-latest.zip"

def update_robol():
    print("Checking for updates...")
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    try:
        print("Downloading latest version...")
        urllib.request.urlretrieve(UPDATE_URL, tmp.name)
    except Exception as e:
        print("Download failed:", e)
        return

    print("Installing update...")
    cmd = [sys.executable, "-m", "pip", "install", "--upgrade", tmp.name]
    try:
        subprocess.run(cmd, check=True)
        print("robol updated successfully!")
    except subprocess.CalledProcessError as e:
        print("Installation failed:", e)
    finally:
        try:
            os.remove(tmp.name)
        except:
            pass
