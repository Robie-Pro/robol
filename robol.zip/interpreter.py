
env = {}

def exec_import(module_name):
    module = __import__(module_name)
    env[module_name] = module

def eval_expr(expr):
    parts = expr.split()
    if len(parts) == 1:
        return eval(parts[0], env, env)
    if len(parts) == 2 and "." in parts[0]:
        module, func = parts[0].split(".")
        value = eval(parts[1], env, env)
        return getattr(env[module], func)(value)
    return eval(expr, env, env)

def run_line(line):
    line = line.strip()
    if not line:
        return
    if line.startswith("import "):
        module = line.split(" ", 1)[1]
        exec_import(module)
        return
    if line.startswith("print "):
        expr = line[6:]
        print(eval_expr(expr))
        return
    if "=" in line:
        var, value = line.split("=", 1)
        env[var.strip()] = eval_expr(value.strip())
        return
    eval_expr(line)

def run_file(filename):
    with open(filename, "r") as file:
        for line in file:
            run_line(line)
